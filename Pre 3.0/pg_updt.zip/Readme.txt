COPY THIS OVER OLD POEMGAME.EXE FILE

This fixes some bugs here and there, chiefly involving
private messages.  Also, an "Away" mode has been added
which allows a user to leave the game without disconnecting.